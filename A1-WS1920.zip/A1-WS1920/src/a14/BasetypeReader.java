package a14;

import java.util.Scanner;

public class BasetypeReader {

    public static void main(String[] args) {
        countBaseTypes();
    }

    private static void countBaseTypes(){
        // TODO
    }
}
