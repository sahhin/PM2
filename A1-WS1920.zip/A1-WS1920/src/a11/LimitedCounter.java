package a11;

public class LimitedCounter  extends Counter{
    @Override
    public int inc() {
        return 0;
    }

    @Override
    public int start() {
        return 0;
    }

    @Override
    public int tally() {
        return 0;
    }

    @Override
    public int reset() {
        return 0;
    }
}
